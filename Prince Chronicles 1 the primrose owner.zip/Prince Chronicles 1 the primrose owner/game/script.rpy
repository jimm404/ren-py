﻿# Definition of the players
define ME = Character("Morraine", color='#fcba03', what_font="OliveraObl_Demo.ttf", who_font="OliveraObl_Demo.ttf")
define holder = Character("Dad", color='#4287f5', what_font="OliveraObl_Demo.ttf", who_font="OliveraObl_Demo.ttf")
define ACTION = Character("", color="#ffffff", what_font="OliveraObl_Demo.ttf")  # optional color for actions

label start:
    # Filipino version
    holder "Nandito na sila."
    
    ME "Pa! Pa! Wag mo kong iwan!"
    
    ACTION "{i}Lumuhod siya sa harapan ko, at niyakap niya ako ng mahigpit{/i}"
    
    holder "Maging malakas ka Morraine..."
    
    holder "Ang kinabukasan ay nakadepende na sayo..."
    
    holder "Wag kang sumuko Morraine..."
    
    holder "Wag mong ibigay tiwala mo sa ibang tao na hindi mo alam, {i}inhales deeply{/i}"
    
    holder "Mahal kita anak..."
    
    holder "Maging malakas ka nak..."
    
    holder "Nandito lang ako para sayo..."
	
	holder "Palakasin mo loob mo nak"
	
    return